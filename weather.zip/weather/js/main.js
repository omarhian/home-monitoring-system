Vue.component('days-list',{
  template: `<div><h1>{{theTitle}}</h1>
  <ul>
    <li v-for="day in days">
    
    <p>Weather Desc: {{day.weather.description}}</p>
     <p>Date: {{day.datetime}}</p>
      <p>Temperature: {{day.temp}}</p>
      <p>Feels Like: {{day.app_max_temp}}</p>
      
       <p>Wind Speed : {{day.wind_spd}}</p>
        
    </li>
  </ul>
  </div>`,
  props: ['theTitle', 'days']
});
//vm stands for view model, create new Vue instance
var vm = new Vue({
   //bind this instance to div with id of app
   el: "#app",
   data: {
   	   forecastDays: []  //array of characters from API
     },
    created: function(){
      axios.get('https://api.weatherbit.io/v2.0/forecast/daily?city=London,Ontario,NC&key=7f06f248141a4e7a85201f47f0b6bf05')
      .then(function(response){  
        console.table(response);
        vm.forecastDays = response.data.data
      });
    }
 
});
//components are reusable Vue instances with a name
//a component's data option must be a function, so that each instance can maintain an independent copy of the returned data object